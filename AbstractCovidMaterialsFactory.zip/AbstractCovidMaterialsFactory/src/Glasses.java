public class Glasses implements Material {

	@Override
	public void get() {
		System.out.println("Input Glasses");
	}

}
