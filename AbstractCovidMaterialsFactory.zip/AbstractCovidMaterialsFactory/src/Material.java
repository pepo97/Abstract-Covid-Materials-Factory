public interface Material {
	public void get();
}
