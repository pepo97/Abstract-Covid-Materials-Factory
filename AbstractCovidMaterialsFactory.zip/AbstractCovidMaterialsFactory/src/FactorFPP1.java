public class FactorFPP1 implements Protection {

	@Override
	public void set() {
		System.out.println("Set protection level to FPP1");
	}
}
