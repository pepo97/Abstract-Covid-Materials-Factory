//Example of static types defined in external class
public class ShapeTypes {
	public static String circle = "MASK";
	public static String rectangle = "GLASSES";
}
