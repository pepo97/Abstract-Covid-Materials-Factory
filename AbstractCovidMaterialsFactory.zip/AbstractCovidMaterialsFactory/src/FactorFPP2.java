public class FactorFPP2 implements Protection {

	@Override
	public void set() {
		System.out.println("Set protection level to FPP2");
	}
}
