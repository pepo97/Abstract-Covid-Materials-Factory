public class Mask implements Material {
	@Override
	public void get() {
		System.out.println("Input a Mask");
	}
}
