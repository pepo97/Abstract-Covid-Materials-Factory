public interface Protection {
	public void set();
}
